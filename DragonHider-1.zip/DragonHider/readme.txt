
DragonHider

Hides the ugly dragon left and right from your action bar.

