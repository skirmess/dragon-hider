
DragonHider

Hides the ugly dragon left and right from your action bar.

*** Changelog

Version 3
Updated TOC for WoW 3.1.2

Version 2
Updated TOC for WoW 3.0.2
