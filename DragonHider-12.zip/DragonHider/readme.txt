
DragonHider

Hides the ugly dragon left and right from your action bar.

*** Changelog

Version 12
 * Updated TOC for WoW 7.0.0

Version 11
 * Updated TOC for WoW 6.1.0
 * Changed project web page to GitHub
   https://github.com/skirmess/dragon-hider

Version 10
 * Updated TOC for WoW 6.0.0

Version 9
 * Updated TOC for WoW 5.2.0

Version 8
 * Updated for MoP.

Version 7
 * Updated TOC for WoW 4.3.0

Version 6
 * Updated TOC for WoW 4.0.1

Version 5
 * Updated TOC for WoW 3.3.5
 * No longer registers the "PLAYER_LEAVING_WORLD" which was not used
 * EventHandler() is now local.
 * Code cleanup.
 * No longer use an XML file.

Version 4
 * Updated TOC for WoW 3.2
 * Added license information
 * Added link to project main page at
   http://code.google.com/p/dragon-hider/

Version 3
 * Updated TOC for WoW 3.1.2

Version 2
 * Updated TOC for WoW 3.0.2
